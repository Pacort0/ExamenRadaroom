package com.example.examenradaroom.vistas

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.example.examenradaroom.database.sancionDao

@Composable
fun detallesVehiculosMultados(
    navController: NavHostController,
    vehiculoDao: sancionDao,
    context: Context
) {

}