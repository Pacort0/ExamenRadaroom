package com.example.examenradaroom.database

class configuracion {
    companion object {
        var limite: Float = 0f
        var multa: Double = 0.0
        var numVeh: Int = 0
    }
}